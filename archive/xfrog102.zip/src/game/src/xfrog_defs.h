/*

Xfrog - a frogger clone.
Copyright (C) 2000 Gustavo S. Muller

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/


/**************************************************************

  Author:		Gustavo Simi Muller -> muller@netpar.com.br

  Date:			24/01/2000

  Description:	Definitions for XFrog

****************************************************************/


#ifndef _XFROG_DEFS_H
#define _XFROG_DEFS_H


// INCLUDES ///////////////////////////////////////////////////////////////////////////////////


#include "types.h"
#include "mem_man.h"


// DEFINES ////////////////////////////////////////////////////////////////////////////////////


#define CLEAR_STRUCT(wstruct)	{ Memset(&wstruct, 0, sizeof(wstruct)); \
								  wstruct.dwSize = sizeof(wstruct); };

#endif